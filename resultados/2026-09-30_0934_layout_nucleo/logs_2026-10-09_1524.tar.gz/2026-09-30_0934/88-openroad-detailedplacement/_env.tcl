set ::env(STEP_ID) OpenROAD.DetailedPlacement
set ::env(TECH_LEF) /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/techlef/sky130_fd_sc_hd__nom.tlef
set ::env(MACRO_LEFS) "/home/lukas/Projects/neorv32-isfft-sky130/macros/sram_8kbyte_1rw_32x2048_8/sram_8kbyte_1rw_32x2048_8.lef /home/lukas/Projects/neorv32-isfft-sky130/macros/sram_4kbyte_1rw_32x1024_8/sram_4kbyte_1rw_32x1024_8.lef /home/lukas/Projects/neorv32-isfft-sky130/macros/sram_1rw1r_64x256/sram_1rw1r_64x256.lef /home/lukas/Projects/neorv32-isfft-sky130/macros/sram_1rw1r_64x64_wpr2/sram_1rw1r_64x64_wpr2.lef"
set ::env(STD_CELL_LIBRARY) sky130_fd_sc_hd
set ::env(VDD_PIN) VPWR
set ::env(GND_PIN) VGND
set ::env(TECH_LEFS) "\"nom_*\" /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/techlef/sky130_fd_sc_hd__nom.tlef \"min_*\" /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/techlef/sky130_fd_sc_hd__min.tlef \"max_*\" /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/techlef/sky130_fd_sc_hd__max.tlef"
set ::env(PRIMARY_GDSII_STREAMOUT_TOOL) magic
set ::env(DEFAULT_CORNER) nom_tt_025C_1v80
set ::env(STA_CORNERS) "nom_tt_025C_1v80 nom_ss_100C_1v60 nom_ff_n40C_1v95 min_tt_025C_1v80 min_ss_100C_1v60 min_ff_n40C_1v95 max_tt_025C_1v80 max_ss_100C_1v60 max_ff_n40C_1v95"
set ::env(RT_MIN_LAYER) met1
set ::env(RT_MAX_LAYER) met5
set ::env(SCL_GROUND_PINS) "VGND VNB"
set ::env(SCL_POWER_PINS) "VPWR VPB"
set ::env(TRISTATE_CELLS) "\"sky130_fd_sc_hd__ebuf*\""
set ::env(FILL_CELLS) "sky130_fd_sc_hd__fill_2 sky130_fd_sc_hd__fill_1"
set ::env(DECAP_CELLS) sky130_fd_sc_hd__decap_3
set ::env(LIB) "\"*_tt_025C_1v80\" /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib \"*_ss_100C_1v60\" /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/lib/sky130_fd_sc_hd__ss_100C_1v60.lib \"*_ff_n40C_1v95\" /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/lib/sky130_fd_sc_hd__ff_n40C_1v95.lib"
set ::env(CELL_LEFS) "/home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/lef/sky130_ef_sc_hd.lef /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/lef/sky130_fd_sc_hd.lef"
set ::env(CELL_GDS) /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/gds/sky130_fd_sc_hd.gds
set ::env(CELL_VERILOG_MODELS) "/home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/verilog/primitives.v /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/verilog/sky130_fd_sc_hd.v"
set ::env(CELL_BB_VERILOG_MODELS) "/home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/verilog/sky130_fd_sc_hd__blackbox.v /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/verilog/sky130_fd_sc_hd__blackbox_pp.v"
set ::env(CELL_SPICE_MODELS) "/home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_ef_sc_hd__decap_12.spice /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_ef_sc_hd__decap_20_12.spice /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_ef_sc_hd__decap_40_12.spice /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_ef_sc_hd__decap_60_12.spice /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_ef_sc_hd__decap_80_12.spice /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_ef_sc_hd__fill_12.spice /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_ef_sc_hd__fill_2.spice /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_ef_sc_hd__fill_4.spice /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_ef_sc_hd__fill_8.spice /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_fd_sc_hd.spice"
set ::env(CELL_CDLS) /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/cdl/sky130_fd_sc_hd.cdl
set ::env(SYNTH_EXCLUDED_CELL_FILE) /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.tech/openlane/sky130_fd_sc_hd/no_synth.cells
set ::env(PNR_EXCLUDED_CELL_FILE) /home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.tech/openlane/sky130_fd_sc_hd/drc_exclude.cells
set ::env(OUTPUT_CAP_LOAD) 33.442
set ::env(MAX_FANOUT_CONSTRAINT) 10
set ::env(MAX_TRANSITION_CONSTRAINT) 0.75
set ::env(MAX_CAPACITANCE_CONSTRAINT) 0.2
set ::env(CLOCK_UNCERTAINTY_CONSTRAINT) 0.25
set ::env(CLOCK_TRANSITION_CONSTRAINT) 0.1499999999999999944488848768742172978818416595458984375
set ::env(TIME_DERATING_CONSTRAINT) 5.0
set ::env(IO_DELAY_CONSTRAINT) 30.0
set ::env(SYNTH_DRIVING_CELL) sky130_fd_sc_hd__inv_2/Y
set ::env(SYNTH_TIEHI_CELL) sky130_fd_sc_hd__conb_1/HI
set ::env(SYNTH_TIELO_CELL) sky130_fd_sc_hd__conb_1/LO
set ::env(SYNTH_BUFFER_CELL) sky130_fd_sc_hd__buf_2/A/X
set ::env(PLACE_SITE) unithd
set ::env(CELL_PAD_EXCLUDE) "\"sky130_fd_sc_hd__tap*\" \"sky130_fd_sc_hd__decap*\" \"sky130_ef_sc_hd__decap*\" \"sky130_fd_sc_hd__fill*\""
set ::env(DIODE_CELL) sky130_fd_sc_hd__diode_2/DIODE
set ::env(WELLTAP_CELL) sky130_fd_sc_hd__tapvpwrvgnd_1
set ::env(ENDCAP_CELL) sky130_fd_sc_hd__decap_3
set ::env(DESIGN_NAME) asic_top
set ::env(CLOCK_PERIOD) 20.0
set ::env(CLOCK_PORT) clk_i
set ::env(VDD_NETS) vccd1
set ::env(GND_NETS) vssd1
set ::env(DIE_AREA) "0.0 0.0 2000.0 1500.0"
set ::env(MACROS) "sram_8kbyte_1rw_32x2048_8 \"gds /home/lukas/Projects/neorv32-isfft-sky130/macros/sram_8kbyte_1rw_32x2048_8/sram_8kbyte_1rw_32x2048_8.gds.gz lef /home/lukas/Projects/neorv32-isfft-sky130/macros/sram_8kbyte_1rw_32x2048_8/sram_8kbyte_1rw_32x2048_8.lef instances \\\"u_cpu.neorv32_top_inst.memory_system_neorv32_imem_enabled_neorv32_imem_inst.u_sram.u_macro \\\\\\\"location \\\\\\\\\\\\\\\"55.0 890.0\\\\\\\\\\\\\\\" orientation FN\\\\\\\"\\\" vh \\\"\\\" nl \\\"\\\" pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*\\\\\\\" /home/lukas/Projects/neorv32-isfft-sky130/macros/sram_8kbyte_1rw_32x2048_8/sram_8kbyte_1rw_32x2048_8_TT_1p8V_25C.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\" sram_4kbyte_1rw_32x1024_8 \"gds /home/lukas/Projects/neorv32-isfft-sky130/macros/sram_4kbyte_1rw_32x1024_8/sram_4kbyte_1rw_32x1024_8.gds.gz lef /home/lukas/Projects/neorv32-isfft-sky130/macros/sram_4kbyte_1rw_32x1024_8/sram_4kbyte_1rw_32x1024_8.lef instances \\\"u_cpu.neorv32_top_inst.memory_system_neorv32_dmem_enabled_neorv32_dmem_inst.u_sram.u_macro \\\\\\\"location \\\\\\\\\\\\\\\"55.0 55.0\\\\\\\\\\\\\\\" orientation S\\\\\\\"\\\" vh \\\"\\\" nl \\\"\\\" pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*\\\\\\\" /home/lukas/Projects/neorv32-isfft-sky130/macros/sram_4kbyte_1rw_32x1024_8/sram_4kbyte_1rw_32x1024_8_TT_1p8V_25C.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\" sram_1rw1r_64x256 \"gds /home/lukas/Projects/neorv32-isfft-sky130/macros/sram_1rw1r_64x256/sram_1rw1r_64x256.gds.gz lef /home/lukas/Projects/neorv32-isfft-sky130/macros/sram_1rw1r_64x256/sram_1rw1r_64x256.lef instances \\\"u_isfft.u_out_mem \\\\\\\"location \\\\\\\\\\\\\\\"1198.0 1002.0\\\\\\\\\\\\\\\" orientation N\\\\\\\"\\\" vh \\\"\\\" nl \\\"\\\" pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*\\\\\\\" /home/lukas/Projects/neorv32-isfft-sky130/macros/sram_1rw1r_64x256/sram_1rw1r_64x256_TT_1p8V_25C.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\" sram_1rw1r_64x64_wpr2 \"gds /home/lukas/Projects/neorv32-isfft-sky130/macros/sram_1rw1r_64x64_wpr2/sram_1rw1r_64x64_wpr2.gds.gz lef /home/lukas/Projects/neorv32-isfft-sky130/macros/sram_1rw1r_64x64_wpr2/sram_1rw1r_64x64_wpr2.lef instances \\\"u_isfft.u_in_mem \\\\\\\"location \\\\\\\\\\\\\\\"1210.0 100.0\\\\\\\\\\\\\\\" orientation N\\\\\\\"\\\" vh \\\"\\\" nl \\\"\\\" pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*\\\\\\\" /home/lukas/Projects/neorv32-isfft-sky130/macros/sram_1rw1r_64x64_wpr2/sram_1rw1r_64x64_wpr2_TT_1p8V_25C.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\""
set ::env(FALLBACK_SDC) /nix/store/33pw6r3szpqrlxwi0ri36rfq68whzq26-python3-3.13.9-env/lib/python3.13/site-packages/librelane/scripts/base.sdc
set ::env(PAD_EDGE_SPACING) 0.0
set ::env(SET_RC_VERBOSE) 0
set ::env(PDN_CONNECT_MACROS_TO_GRID) 1
set ::env(PDN_MACRO_CONNECTIONS) "\".*u_macro vccd1 vssd1 vccd1 vssd1\" \".*u_in_mem vccd1 vssd1 vccd1 vssd1\" \".*u_out_mem vccd1 vssd1 vccd1 vssd1\""
set ::env(PDN_ENABLE_GLOBAL_CONNECTIONS) 1
set ::env(PNR_SDC_FILE) /home/lukas/Projects/neorv32-isfft-sky130/layout/nucleo/nucleo.sdc
set ::env(DEDUPLICATE_CORNERS) 0
set ::env(PL_OPTIMIZE_MIRRORING) 1
set ::env(PL_MAX_DISPLACEMENT_X) 500
set ::env(PL_MAX_DISPLACEMENT_Y) 100
set ::env(DPL_CELL_PADDING) 0
set ::env(CURRENT_ODB) /home/lukas/Projects/neorv32-isfft-sky130/layout/nucleo/runs/2026-09-30_0934/86-openroad-repairdesignpostgpl/asic_top.odb
set ::env(SAVE_ODB) /home/lukas/Projects/neorv32-isfft-sky130/layout/nucleo/runs/2026-09-30_0934/88-openroad-detailedplacement/asic_top.odb
set ::env(SAVE_DEF) /home/lukas/Projects/neorv32-isfft-sky130/layout/nucleo/runs/2026-09-30_0934/88-openroad-detailedplacement/asic_top.def
set ::env(SAVE_SDC) /home/lukas/Projects/neorv32-isfft-sky130/layout/nucleo/runs/2026-09-30_0934/88-openroad-detailedplacement/asic_top.sdc
set ::env(SAVE_NL) /home/lukas/Projects/neorv32-isfft-sky130/layout/nucleo/runs/2026-09-30_0934/88-openroad-detailedplacement/asic_top.nl.v
set ::env(SAVE_PNL) /home/lukas/Projects/neorv32-isfft-sky130/layout/nucleo/runs/2026-09-30_0934/88-openroad-detailedplacement/asic_top.pnl.v
