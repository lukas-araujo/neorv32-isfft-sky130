source /home/lukas/Projects/neorv32-isfft-sky130/layout/chip/runs/2026-11-02_1923_12sta/modelo/env.tcl
foreach l $LIBS { read_liberty $l }
read_db $ODB
read_sdc /home/lukas/Projects/neorv32-isfft-sky130/layout/nucleo/nucleo.sdc
read_spef $SPEF
set_propagated_clock [all_clocks]
puts "== STA TT do nucleo (conferencia: tem de bater com a etapa 7)"
report_wns
report_tns
report_worst_slack -max
report_worst_slack -min
report_checks -path_delay max -fields {slew cap input_pins} -digits 3 > /home/lukas/Projects/neorv32-isfft-sky130/layout/chip/runs/2026-11-02_1923_12sta/modelo/nucleo_max.rpt
report_checks -path_delay min -digits 3 > /home/lukas/Projects/neorv32-isfft-sky130/layout/chip/runs/2026-11-02_1923_12sta/modelo/nucleo_min.rpt
write_timing_model -library_name asic_top_tt -cell_name asic_top /home/lukas/Projects/neorv32-isfft-sky130/layout/chip/entrada/asic_top_tt.lib
puts "== modelo escrito: /home/lukas/Projects/neorv32-isfft-sky130/layout/chip/entrada/asic_top_tt.lib"
exit
