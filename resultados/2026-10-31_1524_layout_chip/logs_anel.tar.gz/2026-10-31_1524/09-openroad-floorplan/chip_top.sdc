###############################################################################
# Created by write_sdc
###############################################################################
current_design chip_top
###############################################################################
# Timing Constraints
###############################################################################
create_clock -name clk_i -period 20.0000 [get_ports {clk_pad}]
set_clock_transition 0.1500 [get_clocks {clk_i}]
set_clock_uncertainty 0.2500 clk_i
set_input_delay 6.0000 -clock [get_clocks {clk_i}] -add_delay [get_ports {rx_pad}]
set_output_delay 6.0000 -clock [get_clocks {clk_i}] -add_delay [get_ports {tx_pad}]
set_false_path\
    -from [get_ports {rstn_pad}]
set_false_path\
    -through [list [get_ports {vccd_pad}]\
           [get_ports {vdda_pad}]\
           [get_ports {vddio_pad}]\
           [get_ports {vssa_pad}]\
           [get_ports {vssd_pad}]\
           [get_ports {vssio_pad}]]
###############################################################################
# Environment
###############################################################################
###############################################################################
# Design Rules
###############################################################################
