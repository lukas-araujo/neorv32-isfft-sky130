set ODB {/home/lukas/Projects/neorv32-isfft-sky130/layout/nucleo/runs/2026-09-30_0934/136-odb-cellfrequencytables/asic_top.odb}
set SPEF {/home/lukas/Projects/neorv32-isfft-sky130/layout/nucleo/runs/2026-09-30_0934/137-openroad-rcx/nom/asic_top.nom.spef}
set LIBS [list {/home/lukas/Projects/pdks/ciel/sky130/versions/8afc8346a57fe1ab7934ba5a6056ea8b43078e71/sky130A/libs.ref/sky130_fd_sc_hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib} {/home/lukas/Projects/neorv32-isfft-sky130/macros/sram_8kbyte_1rw_32x2048_8/sram_8kbyte_1rw_32x2048_8_TT_1p8V_25C.lib} {/home/lukas/Projects/neorv32-isfft-sky130/macros/sram_4kbyte_1rw_32x1024_8/sram_4kbyte_1rw_32x1024_8_TT_1p8V_25C.lib} {/home/lukas/Projects/neorv32-isfft-sky130/macros/sram_1rw1r_64x256/sram_1rw1r_64x256_TT_1p8V_25C.lib} {/home/lukas/Projects/neorv32-isfft-sky130/macros/sram_1rw1r_64x64_wpr2/sram_1rw1r_64x64_wpr2_TT_1p8V_25C.lib}]
set ::env(CLOCK_PERIOD) {20}
set ::env(CLOCK_PORT) {clk_i}
set ::env(CLOCK_TRANSITION_CONSTRAINT) {0.15}
set ::env(CLOCK_UNCERTAINTY_CONSTRAINT) {0.25}
set ::env(IO_DELAY_CONSTRAINT) {30}
set ::env(MAX_CAPACITANCE_CONSTRAINT) {0.2}
set ::env(MAX_FANOUT_CONSTRAINT) {10}
set ::env(MAX_TRANSITION_CONSTRAINT) {0.75}
set ::env(OUTPUT_CAP_LOAD) {33.442}
set ::env(SYNTH_DRIVING_CELL) {sky130_fd_sc_hd__inv_2/Y}
set ::env(TIME_DERATING_CONSTRAINT) {5}
